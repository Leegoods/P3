﻿using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace RecipeApp1._1.Core
{
    class ObservableObject : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler? PropertyChanged;

        protected void OnProperty([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
            }
    }
}
