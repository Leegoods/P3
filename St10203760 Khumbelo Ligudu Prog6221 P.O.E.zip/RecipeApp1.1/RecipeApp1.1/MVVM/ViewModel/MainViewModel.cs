﻿using RecipeApp1._1.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeApp1._1.MVVM.ViewModel
{
    class MainViewModel : ObservableObject
    {

        public MainViewModel()
        {
    } 
    }
}
